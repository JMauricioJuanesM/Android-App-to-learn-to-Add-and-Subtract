package com.talzzoft.pm_jmjm_04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class act1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act1);
    }
}
