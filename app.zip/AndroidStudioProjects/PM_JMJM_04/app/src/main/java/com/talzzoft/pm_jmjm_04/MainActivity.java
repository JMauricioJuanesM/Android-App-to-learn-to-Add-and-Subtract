package com.talzzoft.pm_jmjm_04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button numRan = (Button)findViewById(R.id.btn_num);
        final Button numSum0 = (Button)findViewById(R.id.btn_sum1);
        Button numSum1 = (Button)findViewById(R.id.btn_sum2);
        Button numSum2 = (Button)findViewById(R.id.btn_sum3);
        Button numSum3 = (Button)findViewById(R.id.btn_sum4);
        Button newBtn = (Button)findViewById(R.id.btn_new);
        final String champMessage = "AHH PRRO, GANASTE! :D";
        final String loserMessage = "TAS MAL MIJO :v";
        final Button btnRes = (Button)findViewById(R.id.btn_res);
        final int[] options = assignBool();

        printOperations(createNumbers(), options ,numRan, numSum0, numSum1, numSum2, numSum3);
        restartButton(newBtn);

        numSum0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(options[0]==1){
                    btnRes.setText(champMessage);
                    btnRes.setBackgroundColor(Color.red(0));
                }else{
                    btnRes.setText(loserMessage);
                }
            }
        });

        numSum1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(options[1]==1){
                    btnRes.setText(champMessage);
                    btnRes.setBackgroundColor(Color.red(0));
                }else{
                    btnRes.setText(loserMessage);
                }
            }
        });
        numSum2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(options[2]==1){
                    btnRes.setBackgroundColor(Color.red(0));
                    btnRes.setText(champMessage);
                }else{
                    btnRes.setText(loserMessage);
                }
            }
        });
        numSum3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(options[3]==1){
                    btnRes.setBackgroundColor(Color.red(0));
                    btnRes.setText(champMessage);
                }else{
                    btnRes.setText(loserMessage);
                }
            }
        });
    }

    public int[] createNumbers(){
        int numran = 0,num0 = 0,num1 = 0,num2 = 0,num3 = 0;
        numran = randomNumber(2,100,num0,num1,num2,num3);
        num0 = randomNumber(1,99,numran,num1,num2,num3);
        num1 = randomNumber(1,99,num0,numran,num2,num3);
        num2 = randomNumber(1,99,num0,num1,numran,num3);
        num3 = randomNumber(1,99,num0,num1,num2,numran);
       int[] numbers = {numran,num0,num1,num2,num3};
       return numbers;
    }

    public int randomNumber(int min, int max,int n0, int n1, int n2,int n3){
        int res = 0;
        boolean unic = false;

       while(unic==false){
            res = new Random().nextInt((max - min) + 1) + min;
            if(res!=n0 && res!=n1 && res!=n2 && res!=n3){
                unic = true;
            }
        }
        return res;
    }

    public void printOperations(int[] nums, int[] options, Button numRan, Button numSum0, Button numSum1, Button numSum2, Button numSum3){

        numRan.setText(""+nums[0]+" =");
        setOperations(numSum0,nums[0],nums[1],options[0]);
        setOperations(numSum1,nums[0],nums[2],options[1]);
        setOperations(numSum2,nums[0],nums[3],options[2]);
        setOperations(numSum3,nums[0],nums[4],options[3]);
    }

    public void setOperations(Button btn, int numPri,int numSec, int option){
        int plus,min;
        if (option==0) {
            int error = new Random().nextInt((10 - 1) + 1) + 1;
            plus = numPri - numSec - error;
            min = numSec - numPri + error;
        }else{
            plus = numPri - numSec;
            min = numSec - numPri;
        }
        if (numSec < numPri) {
            btn.setText(plus + " + " + numSec);
        } else {
            btn.setText(numSec + " - " + min);
        }
    }

    public int[] assignBool(){
        int[] options = {0,0,0,0};
        int ran = new Random().nextInt((3 - 0) + 1) + 0;
        for (int i = 0;i<4;i++){
            if (i==ran){
                options[i] = 1;
            }else {
                options[i] = 0;
            }
        }
        return options;
    }

    public void restartButton(Button newBtn){
        newBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });
    }
}